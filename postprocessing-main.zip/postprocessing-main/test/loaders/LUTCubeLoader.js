import test from "ava";
import { LUTCubeLoader } from "../../";

test("can be created", t => {

	t.truthy(new LUTCubeLoader());

});
