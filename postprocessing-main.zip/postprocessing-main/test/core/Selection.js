import test from "ava";
import { Selection } from "../../";

test("can be instantiated", t => {

	t.truthy(new Selection());

});
