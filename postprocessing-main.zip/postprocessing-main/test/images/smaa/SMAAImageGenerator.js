import test from "ava";
import { SMAAImageGenerator } from "../../../";

test("can be created", t => {

	t.truthy(new SMAAImageGenerator());

});
