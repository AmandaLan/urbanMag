import test from "ava";
import { LuminanceMaterial } from "../../";

test("can be created", t => {

	t.truthy(new LuminanceMaterial());

});
