import test from "ava";
import { SSAOMaterial } from "../../";

test("can be created", t => {

	t.truthy(new SSAOMaterial());

});
