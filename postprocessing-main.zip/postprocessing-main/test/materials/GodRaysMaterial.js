import test from "ava";
import { GodRaysMaterial } from "../../";

test("can be created", t => {

	t.truthy(new GodRaysMaterial());

});
