import test from "ava";
import { CircleOfConfusionMaterial } from "../../";

test("can be created", t => {

	t.truthy(new CircleOfConfusionMaterial());

});
