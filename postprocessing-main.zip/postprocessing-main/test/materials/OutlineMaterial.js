import test from "ava";
import { OutlineMaterial } from "../../";

test("can be created", t => {

	t.truthy(new OutlineMaterial());

});
