import test from "ava";
import { DepthComparisonMaterial } from "../../";

test("can be created", t => {

	t.truthy(new DepthComparisonMaterial());

});
