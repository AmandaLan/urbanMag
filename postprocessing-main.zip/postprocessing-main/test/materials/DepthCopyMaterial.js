import test from "ava";
import { DepthCopyMaterial } from "../../";

test("can be created", t => {

	t.truthy(new DepthCopyMaterial());

});
