import test from "ava";
import { MaskMaterial } from "../../";

test("can be created", t => {

	t.truthy(new MaskMaterial());

});
