import test from "ava";
import { CopyMaterial } from "../../";

test("can be created", t => {

	t.truthy(new CopyMaterial());

});
